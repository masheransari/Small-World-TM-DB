package com.example.smallworld_tm_db.application

object AppConstants {

    //API
    const val BASE_URL = "https://api.themoviedb.org/3/"
    const val IMAGE_URL = "https://image.tmdb.org/t/p/w500/"
    const val API_KEY = "237cf84a0c6390e72600cb174359f824"
}